import classes from './Font.module.css';

const Font = ({small}) => {
    return <div className={`${classes.font} ${small ? classes.small : ''}`}>Font Component</div>
}

export default Font;