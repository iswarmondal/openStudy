import classes from './Members.module.css';

const Members = () => {
    return (
        <div className={classes.container}>Hello</div>
    )
}

export default Members;