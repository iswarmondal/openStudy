const Points = () => {
    return (
        <div style={{ "width": "fit-content", "fontSize": "25px", "color": "white" }}>12</div>
    )
}

export default Points;