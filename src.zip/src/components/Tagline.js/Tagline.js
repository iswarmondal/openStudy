const Tagline = () => {
    return (
        <div style={{"color": "#6C63FF", "fontSize": "25px"}}>Bring your friends to study with you</div>
    )
}

export default Tagline;