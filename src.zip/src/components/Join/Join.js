import classes from './Join.module.css';

const Join = () => {
    return (
        <div className={classes.container}>
            okjn
        </div>
    )
}

export default Join;