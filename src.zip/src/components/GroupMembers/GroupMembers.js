import classes from './GroupMembers.module.css';

const GroupMembers = ({name, points}) => {
    return (
        <div className={classes.container}>
            <div>{name}</div>
            <div>({points})</div>
        </div>
    )
}

export default GroupMembers;