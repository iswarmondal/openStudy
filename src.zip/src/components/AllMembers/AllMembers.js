import Members from "../components/Members/Members"
import classes from './AllMembers.module.css';
import Button from '../components/Button/Button';

const AllMembers = () => {
    return (
        <div>
            <div className={classes.container}>
                <Members />
                <Members />
                <Members />
                <Members />
                <Members />
                <Members />
                <Members />
                <Members />
                <Members />
            </div>
            <div className={classes.action}>
                <Button />
                <Button />
                <Button />
            </div>
        </div>
    )
}

export default AllMembers;