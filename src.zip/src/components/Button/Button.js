import classes from './Button.module.css';

const Button = ({ small }) => {
    return (
        <div className={`${classes.btn} ${small ? classes.small : ''}`}>
            Button Component
            {console.log(`classes.btn ${small ? 'classes.small' : ''}`)}
        </div>
    )
}

export default Button;