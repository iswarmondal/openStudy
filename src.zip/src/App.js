import './App.css';
import classes from './App.module.css';
import GroupMembers from './components/GroupMembers/GroupMembers';

function App() {
  return (
    <div className={classes["gradient-background"]}>
      <GroupMembers name={"Ayush"} points={100} />
    </div>
  );
}

export default App;
